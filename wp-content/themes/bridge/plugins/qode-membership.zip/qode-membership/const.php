<?php

define('QODE_MEMBERSHIP_VERSION', '1.0.1');
define('QODE_MEMBERSHIP_ABS_PATH', dirname(__FILE__));
define('QODE_MEMBERSHIP_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('QODE_MEMBERSHIP_SHORTCODES_PATH', QODE_MEMBERSHIP_ABS_PATH.'/shortcodes');