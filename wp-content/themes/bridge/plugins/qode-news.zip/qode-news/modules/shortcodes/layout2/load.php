<?php

include_once QODE_NEWS_SHORTCODES_PATH.'/layout2/functions.php';
include_once QODE_NEWS_SHORTCODES_PATH.'/layout2/layout2.php';