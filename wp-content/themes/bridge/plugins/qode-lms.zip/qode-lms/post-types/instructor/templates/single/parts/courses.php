<?php
echo qode_execute_shortcode( 'qode_course_list', $courses );