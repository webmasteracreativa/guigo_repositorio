<h4 class="qode-quiz-single-title">
	<?php the_title(); ?>
</h4>