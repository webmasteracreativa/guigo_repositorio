<?php

include_once QODE_TOURS_CPT_PATH . '/tours/widgets/tour-list-widget/functions.php';
include_once QODE_TOURS_CPT_PATH . '/tours/widgets/tour-list-widget/tour-list.php';