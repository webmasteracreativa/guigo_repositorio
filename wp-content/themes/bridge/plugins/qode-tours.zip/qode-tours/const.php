<?php

define('QODE_TOURS_VERSION', '1.0.2');
define('QODE_TOURS_ABS_PATH', dirname(__FILE__));
define('QODE_TOURS_REL_PATH', dirname(plugin_basename(__FILE__)));
define('QODE_TOURS_URL_PATH', plugin_dir_url( __FILE__ ));
define('QODE_TOURS_CPT_PATH', QODE_TOURS_ABS_PATH.'/post-types');
define('QODE_TOURS_ASSETS_PATH', QODE_TOURS_ABS_PATH.'/assets');
define('QODE_TOURS_ASSETS_URL_PATH', QODE_TOURS_URL_PATH.'assets');