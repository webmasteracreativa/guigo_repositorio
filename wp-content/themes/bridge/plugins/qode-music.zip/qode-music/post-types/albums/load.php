<?php

include_once QODE_MUSIC_CPT_PATH.'/albums/albums-register.php';
include_once QODE_MUSIC_CPT_PATH.'/albums/helper-functions.php';
include_once QODE_MUSIC_CPT_PATH.'/albums/shortcodes/shortcodes-functions.php';
include_once QODE_MUSIC_CPT_PATH.'/albums/artists-custom-fields.php';